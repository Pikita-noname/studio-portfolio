(() => {
  const dialog = document.querySelector('.image-viewer');
  if (!dialog || typeof dialog.showModal !== 'function') return;

  const image = dialog.querySelector('[data-viewer-image]');
  const stage = dialog.querySelector('[data-viewer-stage]');
  const zoom = dialog.querySelector('[data-viewer-zoom]');
  const close = dialog.querySelector('[data-viewer-close]');
  const status = dialog.querySelector('[data-viewer-status]');
  const message = dialog.querySelector('[data-viewer-message]');
  const retry = dialog.querySelector('[data-viewer-retry]');
  let opener;
  let request = 0;
  let backdropPress = false;

  const setZoom = (expanded, point = { x: .5, y: 0 }) => {
    if (expanded) image.style.setProperty('--viewer-zoom-width', Math.max(image.naturalWidth, image.getBoundingClientRect().width * 2) + 'px');
    dialog.classList.toggle('is-zoomed', expanded);
    zoom.setAttribute('aria-pressed', String(expanded));
    const label = expanded ? 'Fit image' : 'Zoom image';
    zoom.setAttribute('aria-label', label);
    zoom.title = label;
    stage.scrollTo({ left: 0, top: 0, behavior: 'instant' });
    if (expanded) requestAnimationFrame(() => {
      if (!dialog.open || !dialog.classList.contains('is-zoomed')) return;
      stage.scrollTo({
        left: point.x * image.offsetWidth - stage.clientWidth / 2,
        top: point.y * image.offsetHeight - stage.clientHeight / 2,
        behavior: 'instant'
      });
    });
  };

  const loadFullImage = () => {
    const version = ++request;
    status.hidden = false;
    retry.hidden = true;
    message.textContent = 'Loading image…';
    const full = new Image();
    full.onload = () => {
      if (version !== request || !dialog.open) return;
      image.src = full.src;
      image.style.setProperty('--viewer-image-width', full.naturalWidth + 'px');
      dialog.classList.toggle('is-tall', full.naturalHeight / full.naturalWidth > 1.2);
      status.hidden = true;
    };
    full.onerror = () => {
      if (version !== request || !dialog.open) return;
      message.textContent = 'The full-size image could not load.';
      retry.hidden = false;
    };
    full.src = opener.href;
  };

  document.addEventListener('click', event => {
    const trigger = event.target.closest('[data-image-viewer]');
    if (!trigger) return;
    event.preventDefault();
    opener = trigger;
    const preview = trigger.querySelector('img');
    image.src = preview.currentSrc || preview.src;
    image.alt = preview.alt;
    image.style.setProperty('--viewer-image-width', (preview.naturalWidth || preview.width) + 'px');
    dialog.classList.toggle('is-tall', (preview.naturalHeight || preview.height) / (preview.naturalWidth || preview.width) > 1.2);
    setZoom(false);
    document.documentElement.classList.add('is-image-viewer-open');
    dialog.showModal();
    stage.scrollTo({ left: 0, top: 0, behavior: 'instant' });
    close.focus({ preventScroll: true });
    loadFullImage();
  });

  zoom.addEventListener('click', () => setZoom(!dialog.classList.contains('is-zoomed')));
  image.addEventListener('click', event => {
    const bounds = image.getBoundingClientRect();
    setZoom(!dialog.classList.contains('is-zoomed'), {
      x: Math.max(0, Math.min(1, (event.clientX - bounds.left) / bounds.width)),
      y: Math.max(0, Math.min(1, (event.clientY - bounds.top) / bounds.height))
    });
  });
  close.addEventListener('click', () => dialog.close());
  retry.addEventListener('click', loadFullImage);
  dialog.addEventListener('keydown', event => {
    if (event.key !== 'Tab') return;
    const stops = [...dialog.querySelectorAll('button:not([disabled]), [tabindex="0"]')]
      .filter(element => element.getClientRects().length);
    const first = stops[0];
    const last = stops[stops.length - 1];
    if (event.shiftKey && document.activeElement === first) {
      event.preventDefault();
      last.focus();
    } else if (!event.shiftKey && document.activeElement === last) {
      event.preventDefault();
      first.focus();
    }
  });
  dialog.addEventListener('pointerdown', event => {
    backdropPress = event.target === stage || event.target === dialog;
  });
  dialog.addEventListener('click', event => {
    if (backdropPress && (event.target === stage || event.target === dialog)) dialog.close();
    backdropPress = false;
  });
  dialog.addEventListener('close', () => {
    ++request;
    document.documentElement.classList.remove('is-image-viewer-open');
    setZoom(false);
    status.hidden = true;
    image.removeAttribute('src');
    if (opener?.isConnected) opener.focus({ preventScroll: true });
  });
})();
