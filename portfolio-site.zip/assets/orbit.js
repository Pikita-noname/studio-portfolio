(() => {
  const orbit = document.querySelector('[data-project-orbit]');
  if (!orbit) return;
  const parameters = new URLSearchParams(location.search);
  // Local QA path: no controller, matching the unenhanced component behavior.
  if (parameters.get('preview-static') === '1') return;

  const preference = window.matchMedia('(prefers-reduced-motion: reduce)');
  const phone = window.matchMedia('(max-width: 700px)');
  const ribbon = orbit.querySelector('.orbit-marquee');
  const track = ribbon.querySelector('.marquee-track');
  // The query is a local QA override; the OS preference always wins.
  const forceReduced = parameters.get('reduce') === '1';
  let visible = false;
  let focused = false;
  let pointerHeld = false;
  let gesture;
  let dragged = false;
  let coast;
  const resetFocusPosition = () => {
    orbit.style.removeProperty('--preview-focus-x');
    orbit.style.removeProperty('--preview-focus-y');
  };

  const update = () => {
    const reduced = preference.matches || forceReduced;
    orbit.classList.toggle('is-orbit-reduced', reduced);
    orbit.classList.toggle('is-orbit-running', visible && !document.hidden && !reduced && !focused && !pointerHeld);
    orbit.classList.add('is-motion-ready');
  };

  const stopCoast = () => {
    coast?.kill();
    coast = null;
  };
  const seekRibbon = (state, distance) => {
    // Seek the existing CSS loop; wrapping by one identical group is seamless.
    const time = state.time + distance / state.width * state.duration;
    state.animation.currentTime = ((time % state.duration) + state.duration) % state.duration;
  };
  const endGesture = event => {
    if (!gesture || (event && gesture.id !== event.pointerId)) return;
    const state = gesture;
    gesture = null;
    if (ribbon.hasPointerCapture(state.id)) ribbon.releasePointerCapture(state.id);
    if (!state.horizontal || event?.type !== 'pointerup') return;
    // A short coast follows the last movement, without a second animation loop.
    const velocity = performance.now() - state.lastAt < 80 ? state.velocity : 0;
    if (Math.abs(velocity) < 0.08 || !window.gsap) return;
    const position = { distance: state.distance };
    coast = window.gsap.to(position, {
      distance: state.distance + Math.max(-180, Math.min(180, velocity * 160)),
      duration: 0.28, ease: 'power2.out',
      onUpdate: () => seekRibbon(state, position.distance),
      onComplete: () => { coast = null; },
    });
  };

  orbit.addEventListener('pointerdown', event => {
    stopCoast();
    if (gesture && gesture.id !== event.pointerId) {
      endGesture();
      return;
    }
    dragged = false;
    // Repeat copies are clickable, but never take focus inside an aria-hidden group.
    if (event.target.closest('.marquee-repeat .preview-link')) event.preventDefault();
    pointerHeld = true;
    update();
    if (!phone.matches || !event.isPrimary || event.pointerType === 'mouse' ||
        preference.matches || forceReduced || focused || !ribbon.contains(event.target)) return;
    const animation = track.getAnimations().find(item => item.animationName === 'project-ribbon');
    const width = track.querySelector('.marquee-group').getBoundingClientRect().width;
    if (!animation || !width) return;
    gesture = {
      id: event.pointerId, x: event.clientX, y: event.clientY,
      time: Number(animation.currentTime) || 0,
      duration: Number(animation.effect.getTiming().duration), width, animation,
      horizontal: false, distance: 0, lastX: event.clientX,
      lastAt: performance.now(), velocity: 0,
    };
  });
  ribbon.addEventListener('pointermove', event => {
    if (!gesture || gesture.id !== event.pointerId) return;
    const dx = event.clientX - gesture.x;
    const dy = event.clientY - gesture.y;
    if (!gesture.horizontal) {
      if (Math.max(Math.abs(dx), Math.abs(dy)) < 9) return;
      if (Math.abs(dy) >= Math.abs(dx)) {
        endGesture();
        return;
      }
      gesture.horizontal = true;
      dragged = true;
      ribbon.setPointerCapture(event.pointerId);
    }
    const now = performance.now();
    const elapsed = now - gesture.lastAt;
    if (elapsed > 0) gesture.velocity = (event.clientX - gesture.lastX) / elapsed;
    gesture.lastX = event.clientX;
    gesture.lastAt = now;
    gesture.distance = dx;
    seekRibbon(gesture, dx);
  });
  orbit.addEventListener('click', event => {
    if (!dragged || event.detail === 0) return;
    event.preventDefault();
    event.stopPropagation();
  }, true);
  const releasePointer = event => {
    endGesture(event);
    pointerHeld = false;
    update();
  };
  window.addEventListener('pointerup', releasePointer);
  window.addEventListener('pointercancel', releasePointer);
  orbit.addEventListener('focusin', event => {
    focused = Boolean(event.target.closest('.preview-link') && event.target.matches(':focus-visible'));
    if (phone.matches && event.target.matches('.preview-link:focus-visible')) {
      orbit.classList.add('is-keyboard-browsing');
      event.target.scrollIntoView({ block: 'nearest', inline: 'center', behavior: 'instant' });
    } else if (!phone.matches && focused) {
      resetFocusPosition();
      const stage = orbit.getBoundingClientRect();
      const preview = event.target.getBoundingClientRect();
      orbit.style.setProperty('--preview-focus-x', `${stage.left + stage.width / 2 - preview.left - preview.width / 2}px`);
      orbit.style.setProperty('--preview-focus-y', `${stage.top + stage.height / 2 - preview.top - preview.height / 2}px`);
    } else if (!focused) {
      orbit.classList.remove('is-keyboard-browsing');
      ribbon.scrollLeft = 0;
      resetFocusPosition();
    }
    update();
  });
  orbit.addEventListener('focusout', event => {
    if (orbit.contains(event.relatedTarget)) return;
    focused = false;
    resetFocusPosition();
    orbit.classList.remove('is-keyboard-browsing');
    ribbon.scrollLeft = 0;
    update();
  });
  phone.addEventListener('change', () => {
    stopCoast();
    endGesture();
    pointerHeld = false;
    resetFocusPosition();
    if (!phone.matches) {
      orbit.classList.remove('is-keyboard-browsing');
      ribbon.scrollLeft = 0;
    }
    update();
  });
  const cancelInteraction = () => {
    stopCoast();
    endGesture();
    pointerHeld = false;
    update();
  };
  document.addEventListener('visibilitychange', cancelInteraction);
  preference.addEventListener('change', cancelInteraction);
  window.addEventListener('blur', cancelInteraction);
  window.addEventListener('pagehide', cancelInteraction);

  if ('IntersectionObserver' in window) {
    const observer = new IntersectionObserver(([entry]) => {
      visible = entry.isIntersecting;
      update();
    }, { threshold: 0 });
    observer.observe(orbit);
  } else {
    visible = true;
  }
  update();
})();
