(() => {
  const { gsap, ScrollTrigger } = window;
  const parameters = new URLSearchParams(location.search);
  // Unenhanced content remains visible if scripts fail or motion is disabled.
  if (!gsap || !ScrollTrigger || parameters.get('preview-static') === '1') return;

  gsap.registerPlugin(ScrollTrigger);
  ScrollTrigger.config({ ignoreMobileResize: true });

  const root = document.documentElement;
  const forceReduced = parameters.get('reduce') === '1';
  let media;
  let refreshFrame;
  let mounted = false;

  const refresh = () => {
    cancelAnimationFrame(refreshFrame);
    refreshFrame = requestAnimationFrame(() => {
      if (mounted) ScrollTrigger.refresh();
    });
  };

  const mount = () => {
    if (mounted) return;
    mounted = true;
    media = gsap.matchMedia();
    media.add({
      reduced: '(prefers-reduced-motion: reduce)',
      desktop: '(min-width: 701px)',
      phone: '(max-width: 700px)',
    }, context => {
      if (context.conditions.reduced || forceReduced) return;

      const desktop = context.conditions.desktop;
      const distance = desktop ? 24 : 14;
      const reveals = new Map();
      root.classList.add('is-scroll-motion-ready');

      // Separate playheads: scroll never changes the continuous orbit's phase.
      const intro = gsap.timeline({ defaults: { duration: 0.7, ease: 'power3.out' } });
      const opening = gsap.utils.toArray(
        '.hero-message h1 > span, .page-heading > *, .case-heading > *'
      );
      if (opening.length) {
        intro.fromTo(opening,
          { y: distance * 0.65, opacity: 0.65 },
          { y: 0, opacity: 1, stagger: 0.06, clearProps: 'transform,opacity' }, 0);
      }
      const supporting = gsap.utils.toArray('.hero-copy, .hero-actions');
      if (supporting.length) {
        intro.fromTo(supporting,
          { y: distance * 0.5, opacity: 0.65 },
          { y: 0, opacity: 1, stagger: 0.06, clearProps: 'transform,opacity' }, 0.12);
      }

      const sections = gsap.utils.toArray([
        '.proof h2', '.proof-figures > div', '.proof-source', '.work-heading',
        '.project', '.studio-section > *', '.contact > *', '.case-facts > div',
        '.case-lead > *', '.case-story-row > *', '.case-gallery > h2',
        '.screen-figure', '.next-project',
      ].join(', '));

      sections.forEach(element => {
        // Match the responsive layout; hidden extra phone cases need no trigger.
        if (!element.getClientRects().length) return;
        const narrative = element.matches('.case-facts > div, .case-lead > *, .case-story-row > *');
        // A stable row triggers its heading and body together, without measuring
        // the children that move. Reading copy stays revealed after its entrance.
        const trigger = narrative ? element.parentElement : element;
        const visible = trigger.getBoundingClientRect().top < innerHeight * 0.92;
        const timeline = gsap.timeline({
          paused: true,
          defaults: { duration: 0.65, ease: 'power3.out' },
          scrollTrigger: {
            trigger,
            start: 'top 92%',
            end: 'bottom top',
            toggleActions: narrative ? 'play none none none' : 'play reverse play reverse',
            once: narrative,
          },
        });
        // Opacity, rather than visibility, preserves links in the keyboard order.
        timeline.fromTo(element,
          { y: distance, opacity: 0 },
          { y: 0, opacity: 1, immediateRender: !visible });
        if (visible) timeline.progress(1);
        reveals.set(element, timeline);
      });

      const orbitScene = document.querySelector('.orbit-scene');
      if (desktop && orbitScene) {
        gsap.to(orbitScene, {
          y: -56,
          ease: 'none',
          scrollTrigger: {
            trigger: '.landing-hero', start: 'top top', end: 'bottom top',
            scrub: 0.6, invalidateOnRefresh: true,
          },
        });
      }

      gsap.utils.toArray('.project-artwork').forEach(artwork => {
        const visual = artwork.closest('.project-visual');
        gsap.fromTo(artwork,
          { yPercent: -1.5, scale: 1.045 },
          {
            yPercent: 1.5, scale: 1.045, ease: 'none',
            scrollTrigger: {
              trigger: visual, start: 'top bottom', end: 'bottom top',
              scrub: 0.6, invalidateOnRefresh: true,
            },
          });
      });

      gsap.to('.scroll-progress', {
        scaleX: 1, ease: 'none',
        scrollTrigger: { start: 0, end: 'max', scrub: 0.2 },
      });

      // Keyboard navigation completes a reveal immediately; it never waits for it.
      const showFocused = event => {
        for (const [element, timeline] of reveals) {
          if (element.contains(event.target)) timeline.progress(1).pause();
        }
        if (event.target.closest('.hero-message, .page-heading, .case-heading')) {
          intro.progress(1);
        }
      };
      document.addEventListener('focusin', showFocused);

      return () => {
        document.removeEventListener('focusin', showFocused);
        root.classList.remove('is-scroll-motion-ready');
      };
    });
    refresh();
  };

  const unmount = () => {
    mounted = false;
    cancelAnimationFrame(refreshFrame);
    media?.revert();
    media = null;
    root.classList.remove('is-scroll-motion-ready');
  };

  // Loaded fonts/images and opened native disclosures can change trigger positions.
  document.addEventListener('load', refresh, true);
  document.addEventListener('toggle', refresh, true);
  window.addEventListener('pagehide', unmount);
  window.addEventListener('pageshow', mount);
  mount();
  document.fonts?.ready.then(refresh);
})();
