# Official brand assets

- `figma.svg`: Figma full-color icon, unchanged file from `Figma Brand Assets/Figma Icon (Full-color)/Figma Icon (Full-color).svg` in the official archive linked by https://www.figma.com/using-the-figma-brand/ — https://static.figma.com/uploads/4fbf4d754dbbc027ba1530205f8747cd97d532e5
- `github.svg`: white GitHub Invertocat, unchanged file from `GitHub Logos/SVG/GitHub_Invertocat_White.svg` in the official archive linked by https://brand.github.com/foundations/logo — https://brand.github.com/GitHub_Logos.zip

Downloaded18October2026. Brand marks remain the property of their owners. They are decorative secondary references to the requested tools; no endorsement is asserted. Other proposed stack icons are not installed.
